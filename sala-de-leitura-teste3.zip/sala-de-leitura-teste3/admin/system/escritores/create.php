<div class="content form_create">

    <article>

        <header>
            <h1>Adicionar Livro:</h1>
        </header>

        <?php
            $esc = filter_input_array(INPUT_POST, FILTER_DEFAULT);
            if (isset($esc ) && $esc ['SendPostForm']):
            $esc ['esc_status'] = ($esc ['SendPostForm'] == 'Cadastrar' ? '0' : '1' );
            $esc ['esc_cover'] = ( $_FILES['esc_cover']['tmp_name'] ? $_FILES['esc_cover'] : null );
            unset($esc ['SendPostForm']);
            
            require('_models/AdminEscritor.class.php');
             $cadastra = new AdminEscritor;
            $cadastra->ExeCreate($esc );
               
            
            if ($cadastra->getResult()):
                if (!empty($_FILES['gallery_covers']['tmp_name'])):
                    $sendGallery = new AdminEscritor;
                    $sendGallery->gbSend($_FILES['gallery_covers'], $cadastra->getResult());
                endif;
                header('Location: painel.php?exe=escritores/update&create=true&escid=' . $cadastra->getResult());
                else: 
                    WSErro($cadastra->getError()[0], $cadastra->getError()[1]);   
                      
            endif;
            endif;
        ?>


        <form name="PostForm" action="" method="post" enctype="multipart/form-data">

            <label class="label">
                <span class="field">Enviar Capa:</span>
                <input type="file" name="esc_cover" />
            </label>

            <label class="label">
                <span class="field">Escritor:</span>
                 <input type="text" name="esc_title" value="<?php if (isset($esc ['esc_title'])) echo $esc ['esc_title']; ?>" />
            </label>

            <label class="label">
                <span class="field">Conteúdo:</span>
               <textarea class="js_editor" name="esc_content" rows="10"><?php if (isset($esc ['esc_content'])) echo htmlspecialchars($esc ['esc_content']); ?></textarea>
            </label>

            <div class="label_line">

                <label class="label_small">
                    <span class="field">Data:</span>
                     <input type="text" class="formDate center" name="esc_date" value="<?php
                    if (isset($esc ['esc_date'])): echo $esc ['esc_date'];
                    else: echo date('d/m/Y H:i:s');
                    endif;
                    ?>" />
                </label>

<!--                <label class="label_small">
                    <span class="field">Categoria:</span>
                    <select name="post_category">
                        <option value=""> Selecione a categoria: </option>                       
                        
                        <?php
                        $readSes = new Read;
                        $readSes->ExeRead("sl_categories", "WHERE category_parent IS NULL ORDER BY category_title ASC");
                          if ($readSes->getRowCount() >= 1):
                            foreach ($readSes->getResult() as $ses) :
                                echo "<option disabled=\"disabled\" value=\"\"> {$ses['category_title']} </option>";
                                $readCat = new Read;
                                $readCat->ExeRead("sl_categories", "WHERE category_parent = :parent ORDER BY category_title ASC", "parent={$ses['category_id']}");
                                if ($readCat->getRowCount() >= 1):
                                    foreach ($readCat->getResult() as $cat):
                                        echo "<option ";
   
                                 if ($esc ['post_category'] == $cat['category_id']):
                                echo "selected=\"selected\" ";
                            endif;
                                echo "value=\"{$cat['category_id']}\"> &raquo;&raquo; {$cat['category_title']} </option>";
                                    endforeach;
                                endif;
                              
                            
                            endforeach; 
                        endif;
                        ?>
                    </select>
                </label>-->

                <label class="label_small">
                    <span class="field">Editado por:</span>
                    <select name="esc_editor">
                        <option value="<?= $_SESSION['userlogin']['user_id']; ?>"> <?= "{$_SESSION['userlogin']['user_name']} {$_SESSION['userlogin']['user_lastname']}"; ?> </option>
                            <?php
                             $readAut = new Read;
                             $readAut->ExeRead("sl_users", "WHERE user_id != :id AND user_level >= :level ORDER BY user_name ASC", "id={$_SESSION['userlogin']['user_id']}&level=2");
                             if ($readAut->getRowCount() >= 1):
                            foreach ($readAut->getResult() as $aut):
                                 echo "<option ";
                                echo "value=\"{$aut['user_id']}\"> {$aut['user_name']} {$aut['user_lastname']} </option>";
                                 var_dump($readAut);
                            endforeach;
                        endif;
                            ?>
                    </select>
                </label>

            </div><!--/line-->

            <div class="label gbform">

                <label class="label">             
                    <span class="field">Enviar Galeria:</span>
                    <input type="file" multiple name="gallery_covers[]" />
                </label>

                              
            </div>


            <input type="submit" class="btn blue" value="Cadastrar" name="SendPostForm" />
            <input type="submit" class="btn green" value="Cadastrar & Publicar" name="SendPostForm" />

        </form>

    </article>

   <div class="clear"></div>
</div> <!-- content home -->