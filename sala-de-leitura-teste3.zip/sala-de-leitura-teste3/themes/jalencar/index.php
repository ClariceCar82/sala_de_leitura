<?php
$View = new View;
$tpl_g = $View->Load('article_g');
$tpl_p = $View->Load('article_p');
$tpl_po = $View->Load('article_po');
$tpl_esc = $View->Load('article_esc');
$tpl_l = $View->Load('article_l');
$tpl_li = $View->Load('article_li');

?>
<!--HOME SLIDER-->


  <!--Sobre a escola-->    
            <?php
            $cat = Check::CatByName('sobre');
            $post = new Read;
            $post->ExeRead("sl_posts", "WHERE post_status = 1 AND (post_cat_parent = :cat OR post_category = :cat) ORDER BY post_date DESC LIMIT :limit OFFSET :offset", "cat={$cat}&limit=3&offset=0");
            if (!$post->getResult()):
                WSErro('Desculpe, ainda não existem notícias cadastradas. Favor volte mais tarde!', WS_INFOR);
            else:
                foreach ($post->getResult() as $slide):
                    $slide['post_title'] = Check::Words($slide['post_title'], 12);
                    $slide['post_content'] = Check::Words($slide['post_content'], 45);
                    $slide['datetime'] = date('Y-m-d', strtotime($slide['post_date']));
                    $slide['pubdate'] = date('d/m/Y H:i', strtotime($slide['post_date']));
                    $View->Show($slide, $tpl_g);
                endforeach;
            endif;
            ?>          
        </div>
        <div class="slidenav"></div><br>
    <!-- Container Slide -->
    <!--Aconteceu-->   
<!--HOME CONTENT-->
<div class="container">
        <h2>Aconteceu:</h2>
        <section class="aconteceu">
            <div class="centro">            
               <div class="row">
           <?php
            $cat = Check::CatByName('aconteceu');
            $post = new Read;
            $post->ExeRead("sl_posts", "WHERE post_status = 1 AND (post_cat_parent = :cat OR post_category = :cat) ORDER BY post_date DESC LIMIT :limit OFFSET :offset", "cat={$cat}&limit=3&offset=0");
                    if (!$post->getResult()):
                        WSErro("Desculpe, não existem livros cadastradas na categoria ONDE FICAR. Favor, volte depois!", WS_INFOR);
                    else:
                        foreach ($post->getResult() as $emp):
                         $emp['post_title'] = Check::Words($emp['post_title'], 5);
                         $emp['post_content'] = Check::Words($emp['post_content'], 23);
                            $View->Show($emp, $tpl_po);
                        endforeach;
                    endif;
                    ?>
           </div>
           </div>
            </div>           
        </section>
                
           
 <!--Livros-->   

<!--HOME CONTENT-->
 
<div class="container">

        <h2>Livros:</h2>

        <section class="livro">
            <div class="centro">
            
        
  
  
            <div class="row">
           <?php
                    
                    $livros = new Read;
                    $livros->ExeRead("sl_livros", "WHERE livro_status = 1  ORDER BY livro_date DESC LIMIT 3");
                    if (!$livros->getResult()):
                        WSErro("Desculpe, não existem livros cadastradas na categoria ONDE FICAR. Favor, volte depois!", WS_INFOR);
                    else:
                        foreach ($livros->getResult() as $emp):
                         $emp['livro_title'] = Check::Words($emp['livro_title'], 5);
                         $emp['livro_content'] = Check::Words($emp['livro_content'], 23);
                            $View->Show($emp, $tpl_li);
                        endforeach;
                    endif;
                    ?>
              
           </div>
           </div>
            </div>
            

        </section>
              
               <!--HOME CONTENT-->

<div class="container">

        <h2>Escritores:</h2>

        <section class="escritores">
            <div class="centro">
            
           
  
  
            <div class="row">
           <?php
                    
                    $escr = new Read;
                    $escr->ExeRead("sl_escritores", "WHERE esc_status = 1  ORDER BY esc_date DESC LIMIT 3;");
                    if (!$escr->getResult()):
                        WSErro("Desculpe, não existem escritores cadastrados. Favor, volte depois!", WS_INFOR);
                    else:
                        foreach ($escr->getResult() as $empe):
                         $empe['esc_title'] = Check::Words($empe['esc_title'], 5);
                         $empe['esc_content'] = Check::Words($empe['esc_content'], 30);
                            $View->Show($empe, $tpl_esc);
                        endforeach;
                    endif;
                    ?>
           </div>
           </div>
            </div>
        </section>

    

     

                    



    <div class="clear"></div>
</div><!--/ site container -->