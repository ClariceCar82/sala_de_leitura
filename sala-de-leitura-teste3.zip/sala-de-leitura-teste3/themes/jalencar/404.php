<!--HOME CONTENT-->
<div class="site-container">

    <article class="page_notfound">

        <div class="notfounerror">404</div>

        <header class="cat_header">
            <h1>Não encontrado!</h1>
            <p class="tagline">Desculpe, o conteúdo que você procura não existe ou foi removido.</p>
        </header>
    </article>



    <div class="clear"></div>
</div><!--/ site container -->