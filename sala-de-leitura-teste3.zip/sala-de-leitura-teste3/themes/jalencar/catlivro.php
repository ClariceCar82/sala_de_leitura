<?php
if ($Link->getData()):
    extract($Link->getData());
else:
    header('Location: ' . HOME . DIRECTORY_SEPARATOR . '404');
endif;
?>
<!--HOME CONTENT-->
<div class="container">
        <section>
        <header class="cat_header">
            <h2><?= $category_title; ?></h2>
            <p class="tagline"><?= $category_content; ?></p>
        </header>
            
        <?php
        $getPage = (!empty($Link->getLocal()[2]) ? $Link->getLocal()[2] : 1);
        $Pager = new Pager(HOME . '/catlivro/' . $category_name . '/');
        $Pager->ExePager($getPage, 12);

        $readCatl = new Read;
        $readCatl->ExeRead("sl_livros", "WHERE livro_status = 1 AND (livro_category = :catl OR livro_cat_parent = :catl) ORDER BY livro_date DESC LIMIT :limit OFFSET :offset", "catl={$categoryl_id}&limit={$Pager->getLimit()}&offset={$Pager->getOffset()}");
        if (!$readCatl->getResult()):
            $Pager->ReturnPage();
            WSErro("Desculpe, a categoria {$category_title} ainda não tem livros publicados, favor volte mais tarde!", WS_INFOR);
        else:
            $cc = 0;
            $View = new View;
            $tpl_catl = $View->Load('article_li');
            foreach ($readCatl->getResult() as $catl):
                $cc++;
                $class = ($cc % 3 == 0 ? ' class="right"' : null);
                echo "<span{$class}>";
                $catl['livro_title'] = Check::Words($catl['livro_title'], 9);
                $catl['livro_content'] = Check::Words($catl['livro_content'], 20);
                $catl['datetime'] = date('Y-m-d', strtotime($catl['livro_date']));
                $catl['pubdate'] = date('d/m/Y H:i', strtotime($catl['livro_date']));
                $View->Show($catl, $tpl_catl);
                echo "</span>";
            endforeach;
        endif;

        echo '<nav class="paginator">';
        echo '<h2>Mais resultados para NOME DA CATEGORIA</h2>';

        $Pager->ExePaginator("sl_livros", "WHERE livro_status = 1 AND (livro_category = :catl OR livro_cat_parent = :catl)", "catl={$categoryl_id}");
        echo $Pager->getPaginator();

        echo '</nav>';
        ?>
    </section>
    <div class="clear"></div>
    
</div><!--/ site container -->