<?php
if ($Link->getData()):
    extract($Link->getData());
else:
    header('Location:' . HOME . DIRECTORY_SEPARATOR . '404');
endif;

?>
<!--HOME CONTENT-->
<div class="site-container">
    
    <section class="escritor">
        <header class="cat_header">
            <h2><?= $esc_name; ?></h2>
           
        </header>

            <div class="centro">
            
           <div class="container1">
  
  
            <div class="row">
        <?php
        $getPage = (!empty($Link->getLocal()[2]) ? $Link->getLocal()[2] : 1);
        $Pager = new Pager(HOME . '/escritores/' . EscLink . '/');
        $Pager->ExePager($getPage, 12);

        $readCat = new Read;
        $readCat->ExeRead("asl_escritores", "WHERE esc_status = 1 ORDER BY esc_date DESC LIMIT :limit OFFSET :offset", "cat={$EscLink}&limit={$Pager->getLimit()}&offset={$Pager->getOffset()}");
        if (!$readCat->getResult()):
            $Pager->ReturnPage();
            WSErro("Desculpe, a categoria {$category_title} ainda não tem artigos publicados, favor volte mais tarde!", WS_INFOR);
        else:
            $cc = 0;
            $View = new View;
            $tpl_cat = $View->Load('article_esc');
            foreach ($readCat->getResult() as $cat):
                $cc++;
                $class = ($cc % 3 == 0 ? ' class="right"' : null);
                echo "<span{$class}>";
                $cat['esc_title'] = Check::Words($cat['esc_title'], 9);
                $cat['esc_content'] = Check::Words($cat['esc_content'], 20);
                $cat['datetime'] = date('Y-m-d', strtotime($cat['esc_date']));
                $cat['pubdate'] = date('d/m/Y H:i', strtotime($cat['esct_date']));
                $View->Show($cat, $tpl_cat);
                echo "</span>";
            endforeach;
        endif;

        echo '<nav class="paginator">';
      

        $Pager->ExePaginator("sl_escritores", "WHERE esc_status = 1");
        echo $Pager->getPaginator();

        echo '</nav>';
        ?>
                </div>
           </div>
            </div>
            </div>
    </section>
    <div class="clear"></div>
    
</div><!--/ site container -->