<header>
  
    <div class="container">
  <ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link active" href="<?= HOME ?>">Home</a>
    </li>
    <li class="nav-item">
     <a  class="nav-link active" href="<?= HOME ?>/catlivro/literatura-infantojuvenil" title="">Livros</a>
    </li>
    <li class="nav-item">
     <a  class="nav-link active" href="<?= HOME ?>/escritor/" title="">Escritores</a>
    </li>
     <li class="nav-item">    
     <a  class="nav-link active" href="<?= HOME ?>/categoria/aconteceu" title="">Aconteceu</a>
    </li>

    
  
    <li>
           

                   <?php
                    $search = filter_input(INPUT_POST, 's', FILTER_DEFAULT);
                    if (!empty($search)):
                        $search = strip_tags(trim(urlencode($search)));
                        header('Location: ' . HOME . '/pesquisa/' . $search);
                    endif;
                    ?>

        <form class="form-inline my-2 my-lg-0"></li>
        <li><input class="form-control mr-sm-2" type="text" placeholder="Search"></li>
        <li><button class="btn btn-outline-success my-2 my-sm-0" type="submit">Busca</button>
      
    </form>
    </li>     </ul>
</div>
</nav>
  
               

     <div class="titulo">
        <h2>Escola Municipal José de Alencar</h2>

        </div>
        <!-- main nav -->
    </div>
    <!-- Container Header -->
</header> <!-- main header -->