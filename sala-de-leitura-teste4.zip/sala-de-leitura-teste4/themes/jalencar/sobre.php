<?php
if ($Link->getData()):
    extract($Link->getData());
else:
    header('Location: ' . HOME . DIRECTORY_SEPARATOR . '404');
endif;
?>
<!--HOME CONTENT-->
<div class="container">
    <div class="title">
   <h5><?= $post_title; ?></h5>
</div>
</div>
<div class="container">
  
            <div class="imagem1">
               
                        <?= Check::Image('uploads' . DIRECTORY_SEPARATOR . $post_cover, $post_title, 578); ?>
                   
            </div> 
</div>
<div class="container">
                <div class="texto1">
                    <div>
                    <time datetime="<?= date('Y-m-d', strtotime($post_date)); ?>" pubdate>Enviada em: <?= date('d/m/Y H:i', strtotime($post_date)); ?>Hs</time>
                    </div>
                    <div>
                    <?= $post_content; ?>
                </div>
                </div>
            </div>
</div>
<div class="container">
            <div class="veja">
               <?php
                $readGb = new Read;
                $readGb->ExeRead("sl_posts_gallery", "WHERE post_id = :postid ORDER BY gallery_date DESC", "postid={$post_id}");
                if ($readGb->getResult()):
                    ?>
               
               
                   <section>
                       
                       

                            <h5>
                                 
                                GALERIA:
                                <br><br>
                                <p class="tagline">Veja fotos de <mark><?= $post_title; ?></mark></p>
                            </h5>
            </div></div>
        <div class="container">
            <section class="galeria">
                
                            <?php
                            $gb = 0;
                            foreach ($readGb->getResult() as $gallery):
                                $gb++;
                                extract($gallery);
                                ?>
                               
                                 
                                    
                                    <div class="galeria">
                                        
                                        <a href="<?= HOME; ?>/uploads/<?= $gallery_image; ?>" rel="shadowbox[<?= $post_id; ?>]" title="Imagem <?= $gb; ?> do livro <?= $post_title; ?>">
                                            <?= Check::Image('uploads' . DIRECTORY_SEPARATOR . $gallery_image, "Imagem {$gb} do livro {$post_title}", 120, 80); ?>
                                        </a>
                                                  </div>
                                                                                                            
                                <?php
                            endforeach;
                            ?>
                       
            </div>
        
  
     
            
                       
                        <div class="clear"></div>
                    </section>
                <?php endif; ?>
            </div>
            
    
        <?php
           $comentario = filter_input_array(INPUT_POST, FILTER_DEFAULT);
           if(isset($_POST['nome']) && empty($_POST['nome']) == false) :
           $comentario['date'] = date('Y-m-d H:i:s');
           $comentario['post_title'] =  $comentario['post_title'];

       $cadastra= new Create($comentario);
       $cadastra->ExeCreate('comentarios', $comentario);

echo "Seu comentário foi enviado com sucesso!";


var_dump($cadastra);
       endif;     
        ?>
            <div class="container">
            <div class="comentario"> 
      <h5>Deixe seu comentário</h5>
           
               
        <form method="POST" name="SendForm" method="post">
            <input type="hidden" name="date" value="">
            <input type="hidden" name="post_title" value="<?= $post_title; ?>">                     
		Nome:<br/>
                <input type="text" name="nome" size="30"><br/><br/>
                Email:<br/>
                <input type="text" name="email" placeholder="Seu e-mail não vai aparecer" size="50"><br/><br/>
		Comentário:<br/>
                <textarea  rows="3" name="comentario" cols="60"></textarea><br/>
                <input type="submit" value="Enviar">
                

                
	</form>
      
            </div>  
            </div>
      <?php 
   
      ?>
    </div>
        <br><br>
    <?php
                
               $readcoment = new Read;
             $readcoment ->ExeRead("comentarios", "WHERE post_title = :postid ORDER BY date DESC", "postid={$post_title}");
              if ($readcoment->getResult()):
                  foreach ($readcoment->getResult() as $comt) {
                  
               $comt['datetime'] = date('Y-m-d', strtotime($comt['date']));
                  $comt['pubdate'] = date('d/m/Y H:i', strtotime($comt['date']));  
                   
                   
                    ?>

    <div class="container">
    <strong><?php echo $comt['nome']; ?></strong> &nbsp; &nbsp;  <?= $comt['pubdate']; ?><br/>
		<?php echo $comt['comentario']; ?>
		
    </div>
                <?php
                   }  
                   
                endif;
               
                    ?>

       
   

        <div class="clear"></div>
   

