<?php
if ($Link->getData()):
    extract($Link->getData());
else:
    header('Location: ' . HOME . DIRECTORY_SEPARATOR . '404');
endif;
?>
<!--HOME CONTENT-->
<div class="container">
   <h1><?= $esc_title; ?></h1>
</div>
<div class="container">
  <div class="conteudo">
            <div class="imagem">
               
                        <?= Check::Image('uploads' . DIRECTORY_SEPARATOR . $esc_cover, $esc_title, 578); ?>
                   
            </div>  
                <div class="texto">
                    <div>
                    <time datetime="<?= date('Y-m-d', strtotime($esc_date)); ?>" pubdate>Enviada em: <?= date('d/m/Y H:i', strtotime($esc_date)); ?>Hs</time>
                    </div>
                    <div>
                    <?= $esc_content; ?>
                </div>
                </div>
            </div>
</div>
<div class="container">
            <div class="veja">
               <?php
                $readGb = new Read;
                $readGb->ExeRead("sl_escritores_gallery", "WHERE esc_id = :escid ORDER BY gallery_date DESC", "escid={$esc_id}");
                if ($readGb->getResult()):
                    ?>
               
               
                   <section>
                       
                       

                            <h5>
                                 
                                GALERIA:
                                <br><br>
                                <p class="tagline">Veja fotos de <mark><?= $esc_title; ?></mark></p>
                            </h5>
            </div></div>
        <div class="container">
            <section class="galeria">
                
                            <?php
                            $gb = 0;
                            foreach ($readGb->getResult() as $gallery):
                                $gb++;
                                extract($gallery);
                                ?>
                               
                                 
                                    
                                    <div class="galeria">
                                        
                                        <a href="<?= HOME; ?>/uploads/<?= $gallery_image; ?>" rel="shadowbox[<?= $esc_id; ?>]" title="Imagem <?= $gb; ?> do livro <?= $esc_title; ?>">
                                            <?= Check::Image('uploads' . DIRECTORY_SEPARATOR . $gallery_image, "Imagem {$gb} do livro {$esc_title}", 120, 80); ?>
                                        </a>
                                                  </div>
                                                                                                            
                                <?php
                            endforeach;
                            ?>
                       
            </div>
        
  
     
            
                       
                        <div class="clear"></div>
                    </section>
                <?php endif; ?>
            </div>
            
    
       


    </div>
     
  
               
   

        <div class="clear"></div>

