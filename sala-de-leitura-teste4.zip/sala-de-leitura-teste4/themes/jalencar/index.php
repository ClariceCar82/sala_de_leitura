<?php
$View = new View;
$tpl_g = $View->Load('article_g');
$tpl_p = $View->Load('article_p');
$tpl_po = $View->Load('article_po');
$tpl_esc = $View->Load('article_esc');
$tpl_l = $View->Load('article_l');
$tpl_li = $View->Load('article_li');

?>
<!--HOME SLIDER-->


  <!--Sobre a escola-->    
            <?php
            $cat = Check::CatByName('sobre');
            $post = new Read;
            $post->ExeRead("sl_posts", "WHERE post_status = 1 AND (post_cat_parent = :cat OR post_category = :cat) ORDER BY post_date DESC LIMIT :limit OFFSET :offset", "cat={$cat}&limit=3&offset=0");
            if (!$post->getResult()):
                WSErro('Desculpe, ainda não existem notícias cadastradas. Favor volte mais tarde!', WS_INFOR);
            else:
                foreach ($post->getResult() as $slide):
                    $slide['post_title'] = Check::Words($slide['post_title'], 12);
                    $slide['post_content'] = Check::Words($slide['post_content'], 16);
                    $slide['datetime'] = date('Y-m-d', strtotime($slide['post_date']));
                    $slide['pubdate'] = date('d/m/Y H:i', strtotime($slide['post_date']));
                    $View->Show($slide, $tpl_g);
                endforeach;
            endif;
            ?>          
        </div>
        <br>
    <!-- Container Slide -->
    <!--Aconteceu-->   
<!--HOME CONTENT-->
        <section id="aconteceu">
            <div class="container">
                <div class="widget">
                    <div class="widge_title">
                        <div class="widget_title_text">Aconteceu</div>
                        <div class="widget_title_bar"></div>
                    </div>
                    <div class="widget_body">
                         
            <?php
                    $cat = Check::CatByName('aconteceu');
                    $acont = new Read;
                    $acont->ExeRead("sl_posts", "WHERE post_status = 1 AND (post_cat_parent = :cat OR post_category = :cat) ORDER BY post_date DESC LIMIT :limit OFFSET :offset", "cat={$cat}&limit=3&offset=0");
                    if (!$acont->getResult()):
                        WSErro("Desculpe, não existem eventos cadastrados. Favor, volte depois!", WS_INFOR);
                    else:
                        foreach ($acont->getResult() as $aco):
                         $aco['post_title'] = Check::Words($aco['post_title'], 5);
                         $aco['post_content'] = Check::Words($aco['post_content'], 16);
                            $View->Show($aco, $tpl_po);
                        endforeach;
                    endif;
                    ?>
                        
           </div>
           </div>
            </div>           
        </section>
                
           
 <!--Livros-->   

<!--HOME CONTENT-->
<br>
        <section id="aconteceu">
            <div class="container">
                <div class="widget">
                    <div class="widge_title">
                        <div class="widget_title_text">Livros Postados Recentemente</div>
                        <div class="widget_title_bar"></div>
                    </div>
                    <div class="widget_body">
            
           
  
           <?php
                    $cat = Check::CatByName('literatura');
                    $livro = new Read;
                   $livro->ExeRead("sl_posts", "WHERE post_status = 1 AND (post_cat_parent = :cat OR post_category = :cat) ORDER BY post_date DESC LIMIT :limit OFFSET :offset", "cat={$cat}&limit=4&offset=0");
                    if (!$livro->getResult()):
                        WSErro("Desculpe, não existem livros cadastrados. Favor, volte depois!", WS_INFOR);
                    else:
                        foreach ($livro->getResult() as $liv):
                         $liv['post_title'] = Check::Words($liv['post_title'], 5);
                         $liv['post_content'] = Check::Words($liv['post_content'], 30);
                            $View->Show($liv, $tpl_li);
                        endforeach;
                    endif;
                    ?>
             </div>
           </div>
            </div>           
        </section>

        <section id="aconteceu">
            <div class="container">
                <div class="widget">
                    <div class="widge_title">
                        <div class="widget_title_text">Livros Mais Vistos</div>
                        <div class="widget_title_bar"></div>
                    </div>
                    <div class="widget_body">
            
           
  
           <?php
                    $cat = Check::CatByName('literatura');
                    $livro = new Read;
                    $livro->ExeRead("sl_posts", "WHERE post_status = 1 AND post_cat_parent = 18  ORDER BY post_views DESC, post_date DESC LIMIT 4");
                   
                    if (!$livro->getResult()):
                        WSErro("Desculpe, não existem livros cadastrados. Favor, volte depois!", WS_INFOR);
                    else:
                        foreach ($livro->getResult() as $liv):
                         $liv['post_title'] = Check::Words($liv['post_title'], 5);
                         $liv['post_content'] = Check::Words($liv['post_content'], 30);
                            $View->Show($liv, $tpl_li);
                        endforeach;
                    endif;
                    ?>
             </div>
           </div>
            </div>           
        </section>

<br>
         
        </section>



              
               <!--HOME CONTENT-->
<br>
 <section id="aconteceu">
            <div class="container">
                <div class="widget">
                    <div class="widge_title">
                        <div class="widget_title_text">Escritores</div>
                        <div class="widget_title_bar"></div>
                    </div>
                    <div class="widget_body">
            
           <?php
                    
                    $escr = new Read;
                    $escr->ExeRead("sl_escritores", "WHERE esc_status = 1 ORDER BY esc_date DESC LIMIT :limit OFFSET :offset", "&limit=3&offset=1");
                    if (!$escr->getResult()):
                        WSErro("Desculpe, não existem escritores cadastrados. Favor, volte depois!", WS_INFOR);
                    else:
                        foreach ($escr->getResult() as $empe):
                         $empe['esc_title'] = Check::Words($empe['esc_title'], 5);
                         $empe['esc_content'] = Check::Words($empe['esc_content'], 30);
                            $View->Show($empe, $tpl_esc);
                        endforeach;
                    endif;
                    ?>
           </div>
           </div>
            </div>
        </section>

    

     

                    



    <div class="clear"></div>
</div><!--/ site container -->