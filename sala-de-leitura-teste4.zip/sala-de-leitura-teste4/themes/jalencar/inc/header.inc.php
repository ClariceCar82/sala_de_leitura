 <header>
            <div class="container">
                <div class="menu">
                    <nav>
                        <div class="menuMobile">
                            <div class="mm_line"></div>
                            <div class="mm_line"></div>
                            <div class="mm_line"></div>
                        </div>
                        <ul>
                            <li><a href="<?= HOME ?>">Home</a></li>
                            <li><a href="<?= HOME ?>/sobre/e-m-jose-de-alencar" title=""">Sobre</a></li>
                            <li><a href="<?= HOME ?>/categoria/aconteceu" title=""">Aconteceu</a></li>
                            <li><a href="<?= HOME ?>/categoria/literatura" title=""">Livros</a></li>
                            <li><a href="<?= HOME ?>/escritores/escritor" title=""">Escritores</a></li>
                        </ul>
                    </nav>
                     
                </div>
                <div class="busca">
                    <?php
                    $search = filter_input(INPUT_POST, 's', FILTER_DEFAULT);
                    if (!empty($search)):
                        $search = strip_tags(trim(urlencode($search)));
                        header('Location: ' . HOME . '/pesquisa/' . $search);
                    endif;
                    ?>
                    <form name="search" action="" method="post">
                        <input type="text" class="txt" placeholder="Busca"  name="s">                     
                        <input type="submit" value="Buscar" name="sendsearch" class="btnbusca">
                    </form>
                           
                </div>
              
            </div>  
            
        </header>
        <div class="container">
            <div class="titulo">E. M. José de Alencar</div>  
            </div> 