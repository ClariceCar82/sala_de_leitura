 <header>
            <div class="container">
                <div class="menu">
                    <nav>
                        <div class="menuMobile">
                            <div class="mm_line"></div>
                            <div class="mm_line"></div>
                            <div class="mm_line"></div>
                        </div>
                        <ul>
                            <li><a href="">Home</a></li>
                            <li><a href="">Sobre</a></li>
                            <li><a href="">Aconteceu</a></li>
                            <li><a href="">Livros</a></li>
                            <li><a href="">Escritores</a></li>
                        </ul>
                    </nav>
                     
                </div>
                <div class="busca">
                    
                    <form name="search" action="" method="post">
                        <input type="text" class="txt" placeholder="Busca">                     
                        <input type="submit" value="Buscar" class="btnbusca">
                    </form>
                           
                </div>
              
            </div>  
            
        </header>
        <div class="container">
            <div class="titulo">E. M. José de Alencar</div>  
            </div>