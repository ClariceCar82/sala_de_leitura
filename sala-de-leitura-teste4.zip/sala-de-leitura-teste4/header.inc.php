<header>
    <div class="tudo">
    <div class="container">
        <div> 
     
  <ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link active" href="<?= HOME ?>">Home</a>
    </li>
    <li class="nav-item">
     <a  class="nav-link active" href="<?= HOME ?>/categoria/literatura" title="">Livros</a>
    </li>
    <li class="nav-item">
     <a  class="nav-link active" href="<?= HOME ?>/escritores/escritor" title="">Escritores</a>
    </li>
     <li class="nav-item">    
     <a  class="nav-link active" href="<?= HOME ?>/categoria/aconteceu" title="">Aconteceu</a>
    </li>

    <li class="buscadireita"> 
   
  
                             <?php
                    $search = filter_input(INPUT_POST, 's', FILTER_DEFAULT);
                    if (!empty($search)):
                        $search = strip_tags(trim(urlencode($search)));
                        header('Location: ' . HOME . '/pesquisa/' . $search);
                    endif;
                    ?>
       
        <form class="form-inline my-2 my-lg-0" name="search" action="" method="post"></li>
        <li><input class="form-control mr-sm-2" type="text" placeholder="Busca" name="s"></li>
        <li><button class="btn btn-outline-success my-2 my-sm-0" type="submit">Busca</button>
      
    </form>
    </li>       
  
  </ul>
   
        </div>
</div>
   
  

                     
<div class="container">
     <div class="titulo">
        <h2>Escola Municipal José de Alencar</h2>

        </div>
        <!-- main nav -->
    </div>
    </div>
    
    <!-- Container Header -->
</header> <!-- main header -->