<div class="content cat_list">

    <section>

        <h1>Categorias:</h1>

        <?php
        $empty = filter_input(INPUT_GET, 'empty', FILTER_VALIDATE_BOOLEAN);
        if ($empty):
            WSErro("Você tentou editar uma categoria de livro que não existe no sistema!", WS_INFOR);
        endif;

        $delCatl = filter_input(INPUT_GET, 'delete', FILTER_VALIDATE_INT);
        if ($delCatl):
            require ('_models/AdminCategoryLivro.class.php');
            $deletar = new AdminCategoryLivro;
            $deletar->ExeDelete($delCat);
            
            
            WSErro($deletar->getError()[0], $deletar->getError()[1]);
        endif;


        $readSes = new Read;
        $readSes->ExeRead("sl_categorieslivros", "WHERE categoryl_parent IS NULL ORDER BY categoryl_title ASC");
        if (!$readSes->getResult()):

        else:
            foreach ($readSes->getResult() as $liv):
                extract($liv);

                $readLivros = new Read;
                $readLivros->ExeRead("sl_livros", "WHERE livro_cat_parent = :parent", "parent={$categoryl_id}");

                $readCatsl = new Read;
                $readCatsl->ExeRead("sl_categorieslivros", "WHERE categoryl_parent = :parent", "parent={$categoryl_id}");

                $countSesLivros = $readLivros->getRowCount();
                $countSesCatsl = $readCatsl->getRowCount();
                ?>
                <section>

                    <header>
                        <h1><?= $categoryl_title; ?>  <span>( <?= $countSesLivros; ?> livros ) ( <?= $countSesCatsl; ?> Categorias )</span></h1>
                        <p class="tagline"><?= $categoryl_content; ?></p>

                        <ul class="info post_actions">
                            <li><strong>Data:</strong> <?= date('d/m/Y H:i', strtotime($categoryl_date)); ?>Hs</li>
                            <li><a class="act_view" target="_blank" href="../catlivro/<?= $categoryl_name; ?>" title="Ver no site">Ver no site</a></li>
                            <li><a class="act_edit" href="painel.php?exe=categories/update&catlid=<?= $categoryl_id; ?>" title="Editar">Editar</a></li>
                            <li><a class="act_delete" href="painel.php?exe=categories/index&delete=<?= $categoryl_id; ?>" title="Excluir">Deletar</a></li>
                        </ul>
                    </header>

                    <h2>Subcategorias:</h2>

                    <?php
                    $readSub = new Read;
                    $readSub->ExeRead("sl_categorieslivros", "WHERE categoryl_parent = :subparent", "subparent={$categoryl_id}");
                    if (!$readSub->getResult()):

                    else:
                        $a = 0;
                        foreach ($readSub->getResult() as $sub):
                            $a++;

                            $readCatPosts = new Read;
                            $readCatPosts->ExeRead("sl_posts", "WHERE post_category = :categorylid", "categorylid={$sub['categoryl_id']}");
                            ?>
                            <article<?php if ($a % 3 == 0) echo ' class="right"'; ?>>
                                <h1><a target="_blank" href="../catlivro/<?= $sub['categoryl_name']; ?>" title="Ver Categoria"><?= $sub['categoryl_title']; ?></a>  ( <?= $readCatPosts->getRowCount(); ?> livros )</h1>

                                <ul class="info post_actions">
                                    <li><strong>Data:</strong> <?= date('d/m/Y H:i', strtotime($sub['categoryl_date'])); ?>Hs</li>
                                    <li><a class="act_view" target="_blank" href="../catlivro/<?= $sub['categoryl_name']; ?>" title="Ver no site">Ver no site</a></li>
                                    <li><a class="act_edit" href="painel.php?exe=categories/update&catlid=<?= $sub['categoryl_id']; ?>" title="Editar">Editar</a></li>
                                    <li><a class="act_delete" href="painel.php?exe=categories/index&delete=<?= $sub['categoryl_id']; ?>" title="Excluir">Deletar</a></li>
                                </ul>
                            </article>
                            <?php
                        endforeach;
                    endif;
                    ?>

                </section>
                <?php
            endforeach;
        endif;
        ?>

        <div class="clear"></div>
    </section>

    <div class="clear"></div>
</div> <!-- content home -->