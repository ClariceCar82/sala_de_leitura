 <?php
  
$link = mysql_connect("127.0.0.1", "musico1", "adm6914tecax");
mysql_select_db("musico1_biblioteca", $link);

?>