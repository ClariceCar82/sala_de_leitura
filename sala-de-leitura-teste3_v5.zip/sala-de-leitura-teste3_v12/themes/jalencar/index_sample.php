<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="mit" content="2017-12-13T11:31:37-02:00+46305">
          <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>E.M. José de Alencar</title>
            <meta name="description" content="Site da Escola Municipal José de Alencar">
            <meta name="author" content="Clarice Cardeman">
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
 
        <!--[if lt IE 9]>
            <script src="../../_cdn/html5.js"></script>
         <![endif]-->   
    </head>
    <body>

        <header>
  
    <div class="container">
  <ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link active" href="<?= HOME ?>">Home</a>
    </li>
    <li class="nav-item">
     <a  class="nav-link active" href="<?= HOME ?>/catlivro/livro" title="">Livros</a>
    </li>
    <li class="nav-item">
     <a  class="nav-link active" href="<?= HOME ?>/escritores" title="">Escritores</a>
    </li>
     <li class="nav-item">    
     <a  class="nav-link active" href="<?= HOME ?>/categoria/aconteceu-1" title="">Aconteceu</a>
    </li>

    
  
    <li>
           
                            <form name="search" action="" method="post">
                                <input class="fls" type="text" name="s" />
                                <input class="btn" type="submit" name="sendsearch" value="" />
                            </form>
                  
        <form class="form-inline my-2 my-lg-0"></li>
        <li><input class="form-control mr-sm-2" type="text" placeholder="Search"></li>
        <li><button class="btn btn-outline-success my-2 my-sm-0" type="submit">Busca</button>
      
    </form>
    </li>     </ul>
</div>
      </li>

                    </ul>
                </nav> <!-- main nav -->
            </div><!-- Container Header -->
        </header> <!-- main header -->


        
</html>