<!--HOME CONTENT-->

<?php
$EscLink = $Link->getData()['escritor_link'];
$Cat = $Link->getData()['escritor_cat'];
?>

<div class="site-container">

    <section class="page_empresas">
        <header class="emp_header">
            <h2><?= $Cat; ?></h2>
            
        </header>
       
             
             
        <?php
        $getPage = (!empty($Link->getLocal()[2]) ? $Link->getLocal()[2] : 1);
        $Pager = new Pager(HOME . '/escritores/' . $EscLink . '/');
        $Pager->ExePager($getPage, 5);
        
        $readEmp = new Read;
        $readEmp->ExeRead("sl_escritores", "WHERE esc_status = 1 AND esc_category = :cat ORDER BY esc_date DESC LIMIT :limit OFFSET :offset", "cat={$EscLink}&limit={$Pager->getLimit()}&offset={$Pager->getOffset()}");
        if (!$readEmp->getResult()):
            $Pager->ReturnPage();
            WSErro("Desculpe, ainda não existem escritores cadastrados {$Cat}!", WS_INFOR);
        else:
            $cc = 0;
            $View = new View;
            echo '<div class="container">';
            echo ' <div class="row">';
            $tpl_cat = $View->Load('escritor_list');
            foreach ($readEmp->getResult() as $cat):
                $cc++;
                $class = ($cc % 3 == 0 ? ' class="right"' : null);
                echo "<span{$class}>";
                $cat['esc_title'] = Check::Words($cat['esc_title'], 9);
                $cat['esc_content'] = Check::Words($cat['esc_content'], 20);
                $cat['datetime'] = date('Y-m-d', strtotime($cat['esc_date']));
                $cat['pubdate'] = date('d/m/Y H:i', strtotime($cat['esc_date']));
                $View->Show($cat, $tpl_cat);
                echo "</span>";
            endforeach;
            echo '</div>';
            echo '</div>';
           
            echo '<nav class="paginator">';
            
            
            $Pager->ExePaginator("sl_escritores", "WHERE esc_status = 1 AND esc_category = :cat", "cat={$EscLink}");
            echo $Pager->getPaginator();
           
            echo '</nav>';
           
            
        endif;
        ?>          
        

    </section>

   
    <div class="clear"></div>
</div><!--/ site container -->