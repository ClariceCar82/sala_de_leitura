<?php
if ($Link->getData()):
    extract($Link->getData());
else:
    header('Location: ' . HOME . DIRECTORY_SEPARATOR . '404');
endif;
?>
<!--HOME CONTENT-->


    <article class="page_article">

     <div class="container">
            <!--CABEÇALHO GERAL-->
            <header>
                <hgroup>
                   
                    <h1><?= $post_title; ?></h1>
                    
                    <div class="imgint">
                        <?= Check::Image('uploads' . DIRECTORY_SEPARATOR . $post_cover, $post_title, 578); ?>
                    </div>
                  
                    
                    <time datetime="<?= date('Y-m-d', strtotime($post_date)); ?>" pubdate>Enviada em: <?= date('d/m/Y H:i', strtotime($post_date)); ?>Hs</time>

                               
                </hgroup>
            </header>
</div> 
    </article>  <!--CONTEUDO-->
    
            <div class="htmlchars">
    
                <p class="tagline2"><?= $post_content; ?></p>
                
            
                <!--GALERIA-->
                <?php
                $readGb = new Read;
                $readGb->ExeRead("sl_posts_gallery", "WHERE post_id = :postid ORDER BY gallery_date DESC", "postid={$post_id}");
                if ($readGb->getResult()):
                    ?>
                    <section class="gallery">
                        <hgroup>

                            <h3>
                                GALERIA:
                                <p class="tagline">Veja fotos de <mark><?= $post_title; ?></mark></p>
                            </h3>
                        </hgroup>
                        
                               
                        <ul>
                            <?php
                            $gb = 0;
                            foreach ($readGb->getResult() as $gallery):
                                $gb++;
                                extract($gallery);
                                ?>
                                <li>
                                 
                                    
                                    <div class="imgpp">
                                        
                                        <a href="<?= HOME; ?>/uploads/<?= $gallery_image; ?>" rel="shadowbox[<?= $post_id; ?>]" title="Imagem <?= $gb; ?> do livro <?= $post_title; ?>">
                                            <?= Check::Image('uploads' . DIRECTORY_SEPARATOR . $gallery_image, "Imagem {$gb} do livro {$post_title}", 120, 80); ?>
                                        </a>
                                                  </div>
                                   
                                  
                                
                                </li>
                                <?php
                            endforeach;
                            ?>
                        </ul>
                       
                                  
                       
                        <div class="clear"></div>
                    </section>
                <?php endif; ?>
            </div>
            
            
        <!--SIDEBAR-->
        

        <div class="clear"></div>
   

    <!--/ site container -->