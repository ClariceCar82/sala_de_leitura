<footer>
    

    <div>Copyright  © E. M. José de Alencar - Todos os direitos Reservados<br>
    Desenvolvimento Web - Clarice Cardeman</div><!-- footer logo -->
</footer>