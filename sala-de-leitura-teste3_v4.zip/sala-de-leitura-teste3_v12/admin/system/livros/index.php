
<div class="content list_content">

    <section>

        <h1>Postagens:</h1>

        <?php
        $empty = filter_input(INPUT_GET, 'empty', FILTER_VALIDATE_BOOLEAN);
        if ($empty):
            WSErro("Oppsss: Você tentou editar um livro que não existe no sistema!", WS_INFOR);
        endif;


        $action = filter_input(INPUT_GET, 'action', FILTER_DEFAULT);
        if ($action):
            require ('_models/AdminLivros.class.php');

            $livroAction = filter_input(INPUT_GET, 'livro', FILTER_VALIDATE_INT);
            $livroUpdate = new AdminLivros;

            switch ($action):
                case 'active':
                    $livroUpdate->ExeStatus($livroAction, '1');
                    WSErro("O status do livro foi atualizado para <b>ativo</b>. Post publicado!", WS_ACCEPT);
                    break;

                case 'inative':
                    $livroUpdate->ExeStatus($livroAction, '0');
                    WSErro("O status do livro foi atualizado para <b>inativo</b>. Post agora é um rascunho!", WS_ALERT);
                    break;

                case 'delete':
                    $livroUpdate->ExeDelete($livroAction);
                    WSErro($livroUpdate->getError()[0], $livroUpdate->getError()[1]);
                    break;

                default :
                    WSErro("Ação não foi identifica pelo sistema, favor utilize os botões!", WS_ALERT);
            endswitch;
        endif;


        $livroi = 0;
        $getPage = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
        $Pager = new Pager('painel.php?exe=livros/index&page=');
        $Pager->ExePager($getPage, 10);

        $readPosts = new Read;
        $readPosts->ExeRead("sl_livros", "ORDER BY livro_status ASC, livro_date DESC LIMIT :limit OFFSET :offset", "limit={$Pager->getLimit()}&offset={$Pager->getOffset()}");
        if ($readPosts->getResult()):
            foreach ($readPosts->getResult() as $livro):
            
                $livroi++;
                extract($livro);
                $status = (!$livro_status ? 'style="background: #fffed8"' : '');
                ?>
                <article<?php if ($posti % 2 == 0) echo ' class="right"'; ?> <?= $status; ?>>

                          <div class="mini">
                       
                          <img class="mini" src="http://biblioteca-da-musicoterapia.com/jalencar/uploads/<?php echo $livro_cover;?>">
                                                              
                    </div>
                   

                    <h1><a target="_blank" href="../livro/<?= $livro_name; ?>" title="Ver Post"><?= Check::Words($livro_title, 10) ?></a></h1>
                    <ul class="info livro_actions">
                        <li><strong>Data:</strong> <?= date('d/m/Y H:i', strtotime($livro_date)); ?>Hs</li>
                        <li><a class="act_view" target="_blank" href="../artigo/<?= $livro_name; ?>" title="Ver no site">Ver no site</a></li>
                        <li><a class="act_edit" href="painel.php?exe=livros/update&livroid=<?= $livro_id; ?>" title="Editar">Editar</a></li>

                        <?php if (!$livro_status): ?>
                            <li><a class="act_inative" href="painel.php?exe=livros/index&livro=<?= $livro_id; ?>&action=active" title="Ativar">Ativar</a></li>
                        <?php else: ?>
                            <li><a class="act_ative" href="painel.php?exe=livros/index&livro=<?= $livro_id; ?>&action=inative" title="Inativar">Inativar</a></li>
                        <?php endif; ?>

                        <li><a class="act_delete" href="painel.php?exe=livros/index&livro=<?= $livro_id; ?>&action=delete" title="Excluir">Deletar</a></li>
                    </ul>

                </article>
                <?php
            endforeach;

        else:
            $Pager->ReturnPage();
            WSErro("Desculpe, ainda não existem livros cadastrados!", WS_INFOR);
        endif;
        ?>

        <div class="clear"></div>
    </section>

    <?php
    $Pager->ExePaginator("sl_livros");
    echo $Pager->getPaginator();
    ?>

    <div class="clear"></div>
</div> <!-- content home -->

